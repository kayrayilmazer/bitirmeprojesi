package com.example.dakiksaha;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

public class AnaSayfaActivity extends AppCompatActivity {

    ImageView imageView;
    TextView txt_hosgeldiniz, txt_randevu_sayfa_git;
    Button btn_randevu_al;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_ana_sayfa);

        imageView = (findViewById(R.id.imageView));
        txt_hosgeldiniz = (findViewById(R.id.txt_hosgeldiniz));
        txt_randevu_sayfa_git = (findViewById(R.id.txt_randevu_sayfa_git));
        btn_randevu_al = findViewById(R.id.btn_randevu_al);


        btn_randevu_al.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(AnaSayfaActivity.this, Randevu.class));
            }
        });



    }
}
