package com.example.dakiksaha.Fragments;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;

import com.example.dakiksaha.AnaSayfaActivity;
import com.example.dakiksaha.Common.Common;
import com.example.dakiksaha.Model.RandevuBilgileri;
import com.example.dakiksaha.R;
import com.example.dakiksaha.Randevu;
import com.example.dakiksaha.SonActivity;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Calendar;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.OnClick;
import butterknife.Unbinder;

public class Step4Fragment extends Fragment {

    SimpleDateFormat simpleDateFormat;
    LocalBroadcastManager localBroadcastManager;

    Unbinder unbinder;

    @BindView(R.id.txt_randevu_kaleci_text)
    TextView txt_randevu_kaleci_text;
    @BindView(R.id.txt_randevu_time_text)
    TextView txt_randevu_time_text;
    @BindView(R.id.txt_salon_address)
    TextView txt_salon_address;
    @BindView(R.id.txt_salon_name)
    TextView txt_salon_name;
    @BindView(R.id.txt_salon_acılma_saati)
    TextView txt_salon_acılma_saati;
    @BindView(R.id.txt_salon_telefon)
    TextView txt_salon_telefon;

    @OnClick (R.id.btn_onayla)
    void confirmRandevu(){
        startActivity(new Intent(getActivity(), SonActivity.class));

        RandevuBilgileri randevuBilgileri = new RandevuBilgileri();

        //Randevu Bilgileri
        randevuBilgileri.setKaleciId(Common.currentKaleci.getKaleciID());
        randevuBilgileri.setKaleciName(Common.currentKaleci.getName());
        //randevuBilgileri.setCustomerName(Common.currentUser.getName());
        //randevuBilgileri.setCustomerPhone(Common.currentUser.getPhoneNumber());
        randevuBilgileri.setSalonId(Common.currentSalon.getSalonId());
        randevuBilgileri.setSalonAddress(Common.currentSalon.getAddress());
        randevuBilgileri.setSalonName(Common.currentSalon.getName());
        randevuBilgileri.setPhone(Common.currentSalon.getPhone());
        randevuBilgileri.setTime(new StringBuilder(Common.convertTimeSlotToString(Common.currentTimeSlot))
                .append(" at ")
                .append(simpleDateFormat.format(Common.currentDate.getTime())).toString());
        randevuBilgileri.setSlot(Long.valueOf(Common.currentTimeSlot));

        DocumentReference randevuDate =  FirebaseFirestore.getInstance()
                .collection("Halisahalar")
                .document(Common.sehir)
                .collection("Ilce")
                .document(Common.currentSalon.getSalonId())
                .collection("Kaleci")
                .document(Common.currentKaleci.getKaleciID())
                .collection(Common.simpleDateFormat.format(Common.currentDate.getTime()))
                .document(String.valueOf(Common.currentTimeSlot));

        randevuDate.set(randevuBilgileri)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        resetStaticData();
                        getActivity().finish(); //Activity Kapa
                        Toast.makeText(getContext(), "Başarılı!", Toast.LENGTH_SHORT).show();
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                Toast.makeText(getContext(), ""+e.getMessage(), Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void resetStaticData() {
        Common.step = 0;
        Common.currentTimeSlot = -1;
        Common.currentSalon = null;
        Common.currentKaleci = null;
        Common.currentDate.add(Calendar.DATE,0);
    }


    BroadcastReceiver confirmRandevuReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            setData();
        }
    };

    private void setData() {
        txt_randevu_kaleci_text.setText(Common.currentKaleci.getName());
        txt_randevu_time_text.setText(new StringBuilder(Common.convertTimeSlotToString(Common.currentTimeSlot))
        .append(" at ")
        .append(simpleDateFormat.format(Common.currentDate.getTime())));

        txt_salon_address.setText(Common.currentSalon.getAddress());
        txt_salon_name.setText(Common.currentSalon.getName());
        txt_salon_acılma_saati.setText(Common.currentSalon.getOpenHours());
        txt_salon_telefon.setText(Common.currentSalon.getPhone());
    }


    static Step4Fragment instance;
    public static Step4Fragment getInstance() {
        if (instance == null)
            instance = new Step4Fragment();
        return instance;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //Onaylanmış adress göstrme
        simpleDateFormat = new SimpleDateFormat("dd/MM/yyyy");

        localBroadcastManager = LocalBroadcastManager.getInstance(getContext());
        localBroadcastManager.registerReceiver(confirmRandevuReceiver, new IntentFilter(Common.KEY_CONFIRM_RANDEVU));


    }

    @Override
    public void onDestroy() {
        localBroadcastManager.unregisterReceiver(confirmRandevuReceiver);
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        View itemView = inflater.inflate(R.layout.fragment_step_four,container,false);
        unbinder = ButterKnife.bind(this,itemView);

        return itemView;

    }
}
