package com.example.dakiksaha.İntarface;

import java.util.List;

public interface IAllSahaLoadListener {

    void onAllSahaLoadSuccess(List<String> areaNameList);
    void onAllSahaLoadFailed(String message);
}
