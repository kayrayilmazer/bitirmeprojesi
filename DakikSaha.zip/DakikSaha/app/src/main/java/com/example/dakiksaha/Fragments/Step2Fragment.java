package com.example.dakiksaha.Fragments;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dakiksaha.Adapter.MyKaleciAdapter;
import com.example.dakiksaha.Common.Common;
import com.example.dakiksaha.Common.SpacesItemDecoration;
import com.example.dakiksaha.Model.Kaleci;
import com.example.dakiksaha.R;
import com.google.firebase.firestore.CollectionReference;

import java.util.ArrayList;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class Step2Fragment extends Fragment {


    Unbinder unbinder;
    LocalBroadcastManager localBroadcastManager;


    @BindView(R.id.recycler_kaleci)
    RecyclerView recycler_kaleci;


    private BroadcastReceiver kalecidoneReceiver = new BroadcastReceiver() {
        @Override
        public void onReceive(Context context, Intent intent) {
            ArrayList<Kaleci> kaleciArrayList = intent.getParcelableArrayListExtra(Common.KEY_KALECI_LOAD_DONE);
            //Sonra Adaptör Yaratılacak

            MyKaleciAdapter adapter = new MyKaleciAdapter(getContext(),kaleciArrayList);
            recycler_kaleci.setAdapter(adapter);
        }
    };


    static Step2Fragment instance;

    public static Step2Fragment getInstance() {
        if (instance == null)
            instance = new Step2Fragment();
        return instance;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        localBroadcastManager = LocalBroadcastManager.getInstance(getContext());
        localBroadcastManager.registerReceiver(kalecidoneReceiver,new IntentFilter(Common.KEY_KALECI_LOAD_DONE));
    }

    @Override
    public void onDestroy() {
        localBroadcastManager.unregisterReceiver(kalecidoneReceiver);
        super.onDestroy();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        View itemView = inflater.inflate(R.layout.fragment_step_two,container,false);

        unbinder = ButterKnife.bind(this,itemView);

        initView();

        return itemView;
    }

    private void initView() {
        recycler_kaleci.setHasFixedSize(true);
        recycler_kaleci.setLayoutManager(new GridLayoutManager(getActivity(),2));
        recycler_kaleci.addItemDecoration(new SpacesItemDecoration(4));
    }
}
