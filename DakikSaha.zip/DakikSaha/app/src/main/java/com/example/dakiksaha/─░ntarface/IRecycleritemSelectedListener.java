package com.example.dakiksaha.İntarface;

import android.view.View;

public interface IRecycleritemSelectedListener {

    void onItemSelectedListener(View view,int pos);
}
