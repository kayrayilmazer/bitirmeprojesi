package com.example.dakiksaha.Model;

public class RandevuBilgileri {
    private String customerName, Phone, time, kaleciId, kaleciName, salonId, salonName, salonAddress;
    private Long slot;

    public RandevuBilgileri() {

    }

    public RandevuBilgileri(String customerName, String customerPhone, String time, String kaleciId, String kaleciName, String salonId, String salonName, String salonAddress, Long slot) {
        this.customerName = customerName;
        this.Phone = customerPhone;
        this.time = time;
        this.kaleciId = kaleciId;
        this.kaleciName = kaleciName;
        this.salonId = salonId;
        this.salonName = salonName;
        this.salonAddress = salonAddress;
        this.slot = slot;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public String getPhone() {
        return Phone;
    }

    public void setPhone(String customerPhone) {
        this.Phone = customerPhone;
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getKaleciId() {
        return kaleciId;
    }

    public void setKaleciId(String kaleciId) {
        this.kaleciId = kaleciId;
    }

    public String getKaleciName() {
        return kaleciName;
    }

    public void setKaleciName(String kaleciName) {
        this.kaleciName = kaleciName;
    }

    public String getSalonId() {
        return salonId;
    }

    public void setSalonId(String salonId) {
        this.salonId = salonId;
    }

    public String getSalonName() {
        return salonName;
    }

    public void setSalonName(String salonName) {
        this.salonName = salonName;
    }

    public String getSalonAddress() {
        return salonAddress;
    }

    public void setSalonAddress(String salonAddress) {
        this.salonAddress = salonAddress;
    }

    public Long getSlot() {
        return slot;
    }

    public void setSlot(Long slot) {
        this.slot = slot;
    }
}
