package com.example.dakiksaha.İntarface;

import com.example.dakiksaha.Model.Salon;

import java.util.List;

public interface IlceLoadListener  {

    void onIlceLoadSuccess(List<Salon> areaNameList);
    void onIlceLoadFailed(String message);
}
