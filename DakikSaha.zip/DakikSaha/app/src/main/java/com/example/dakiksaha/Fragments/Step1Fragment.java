package com.example.dakiksaha.Fragments;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.recyclerview.widget.GridLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dakiksaha.Adapter.MySalonAdapter;
import com.example.dakiksaha.Common.Common;
import com.example.dakiksaha.Common.SpacesItemDecoration;
import com.example.dakiksaha.Model.Salon;
import com.example.dakiksaha.R;
import com.example.dakiksaha.İntarface.IAllSahaLoadListener;
import com.example.dakiksaha.İntarface.IlceLoadListener;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.jaredrummler.materialspinner.MaterialSpinner;

import java.util.ArrayList;
import java.util.List;

import butterknife.BindView;
import butterknife.ButterKnife;
import butterknife.Unbinder;

public class Step1Fragment extends Fragment implements IAllSahaLoadListener, IlceLoadListener {


    CollectionReference HalisahalarRef;
    CollectionReference ilceRef;

    IAllSahaLoadListener iAllSahaLoadListener;
    IlceLoadListener ilceLoadListener;

    @BindView(R.id.spinner)
    MaterialSpinner spinner;
    @BindView(R.id.recycler_salon)
    RecyclerView recycler_salon;

    Unbinder unbinder;

    //AlertDialog dialog;


    static Step1Fragment instance;

    public static Step1Fragment getInstance(){
        if (instance == null)
            instance = new Step1Fragment();
        return instance;
    }

    @Override
    public void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        //HalisahalarRef = FirebaseFirestore.getInstance();
        HalisahalarRef = FirebaseFirestore.getInstance().collection("Halisahalar");
        iAllSahaLoadListener = this;
        ilceLoadListener = this;

        //dialog = new SpotsDialog.Builder().setContext(getActivity()).build();
    }

    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        super.onCreateView(inflater, container, savedInstanceState);

        View itemView = inflater.inflate(R.layout.fragment_step_one,container,false);
        unbinder = ButterKnife.bind(this,itemView);

        initView();
        loadAllSaha();

        return itemView;
    }

    private void initView() {
        recycler_salon.setHasFixedSize(true);
        recycler_salon.setLayoutManager(new GridLayoutManager(getActivity(),2));
        recycler_salon.addItemDecoration(new SpacesItemDecoration(4));
    }

    private void loadAllSaha() {

        HalisahalarRef.get()
                .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                    @Override
                    public void onComplete(@NonNull Task<QuerySnapshot> task) {
                        if (task.isSuccessful()){
                            List<String> list = new ArrayList<>();
                            list.add("Lutfen Sehir Secin");
                            for(QueryDocumentSnapshot documentSnapshot:task.getResult())
                                list.add(documentSnapshot.getId());
                            iAllSahaLoadListener.onAllSahaLoadSuccess(list);
                        }
                    }
                }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                iAllSahaLoadListener.onAllSahaLoadFailed(e.getMessage());
            }
        });


    }

    @Override
    public void onAllSahaLoadSuccess(List<String> areaNameList) {
        spinner.setItems(areaNameList);
        spinner.setOnItemSelectedListener(new MaterialSpinner.OnItemSelectedListener() {
            @Override
            public void onItemSelected(MaterialSpinner view, int position, long id, Object item) {
                if (position > 0){
                    loadsehirsubesi(item.toString());
                }
                else
                    recycler_salon.setVisibility(View.GONE);
            }
        });
    }

    private void loadsehirsubesi(String sehirName) {
        //dialog.show();

        Common.sehir = sehirName;

        ilceRef = FirebaseFirestore.getInstance()
                .collection("Halisahalar")
                .document(sehirName)
                .collection("Ilce");

        ilceRef.get().addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
            @Override
            public void onComplete(@NonNull Task<QuerySnapshot> task) {
                List<Salon> list = new ArrayList<>();
                if (task.isSuccessful()){

                    for (QueryDocumentSnapshot documentSnapshot:task.getResult())
                    {
                        Salon salon = documentSnapshot.toObject(Salon.class);
                        salon.setSalonId(documentSnapshot.getId());
                        list.add(salon);
                    }
                    ilceLoadListener.onIlceLoadSuccess(list);
                }
            }
        }).addOnFailureListener(new OnFailureListener() {
            @Override
            public void onFailure(@NonNull Exception e) {
                ilceLoadListener.onIlceLoadFailed(e.getMessage());
            }
        });
    }

    @Override
    public void onAllSahaLoadFailed(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();

    }

    @Override
    public void onIlceLoadSuccess(List<Salon> salonList) {
        MySalonAdapter adapter = new MySalonAdapter(getActivity(),salonList);
        recycler_salon.setAdapter(adapter);
        recycler_salon.setVisibility(View.VISIBLE);

        //dialog.dismiss();

    }

    @Override
    public void onIlceLoadFailed(String message) {
        Toast.makeText(getActivity(), message, Toast.LENGTH_SHORT).show();
        //dialog.dismiss();
    }
}
