package com.example.dakiksaha;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

public class SonActivity extends AppCompatActivity {

    ImageView imageView;
    TextView txt_son_yazi, txt_randevu_git;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_son);

        imageView = (findViewById(R.id.logo));
        txt_son_yazi = (findViewById(R.id.txt_yazi));
        txt_randevu_git = (findViewById(R.id.txt_son_git_randevu));

        txt_randevu_git.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                startActivity(new Intent(SonActivity.this, Randevu.class));
            }
        });
    }
}
