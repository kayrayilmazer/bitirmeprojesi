package com.example.dakiksaha.Adapter;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.localbroadcastmanager.content.LocalBroadcastManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.dakiksaha.Common.Common;
import com.example.dakiksaha.Model.TimeSlot;
import com.example.dakiksaha.R;
import com.example.dakiksaha.İntarface.IRecycleritemSelectedListener;

import java.sql.Time;
import java.util.ArrayList;
import java.util.List;

public class MyTimeSlotAdapter extends RecyclerView.Adapter<MyTimeSlotAdapter.MyViewHolder> {

    Context context;
    List<TimeSlot> timeSlotList;
    List<CardView> cardViewList;
    LocalBroadcastManager localBroadcastManager;


    public MyTimeSlotAdapter(Context context){
        this.context = context;
        this.timeSlotList = new ArrayList<>();
        this.localBroadcastManager = LocalBroadcastManager.getInstance(context);
        cardViewList = new ArrayList<>();
    }

    public MyTimeSlotAdapter(Context context, List<TimeSlot> timeSlotList) {
        this.context = context;
        this.timeSlotList = timeSlotList;
        this.localBroadcastManager = LocalBroadcastManager.getInstance(context);
        cardViewList = new ArrayList<>();
    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup viewGroup, int i) {
        View itemView = LayoutInflater.from(context)
                .inflate(R.layout.layout_time_slot,viewGroup,false);

        return new MyViewHolder(itemView);
    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder myViewHolder, int i) {
        myViewHolder.txt_time_slot.setText(new StringBuilder(Common.convertTimeSlotToString(i)).toString());
        if (timeSlotList.size() == 0)
        {
            myViewHolder.cart_time_slot.setCardBackgroundColor(context.getResources().getColor(android.R.color.white));

            myViewHolder.txt_time_slot_acıklama.setText("Müsait");
            myViewHolder.txt_time_slot_acıklama.setTextColor(context.getResources().getColor(android.R.color.black));
            myViewHolder.txt_time_slot.setTextColor(context.getResources().getColor(android.R.color.black));


        }
        else //Bütün Seçenekler Doluysa
        {
            for (TimeSlot slotValue:timeSlotList)
            {
                int slot = Integer.parseInt(slotValue.getSlot().toString());
                if (slot == i)
                {
                    myViewHolder.cart_time_slot.setTag(Common.DISABLE_TAG);
                    myViewHolder.cart_time_slot.setCardBackgroundColor(context.getResources().getColor(android.R.color.darker_gray));

                    myViewHolder.txt_time_slot_acıklama.setText("Dolu");
                    myViewHolder.txt_time_slot_acıklama.setTextColor(context.getResources()
                            .getColor(android.R.color.white));
                    myViewHolder.txt_time_slot.setTextColor(context.getResources().getColor(android.R.color.white));
                }
            }
        }
        if (!cardViewList.contains(myViewHolder.cart_time_slot))
            cardViewList.add(myViewHolder.cart_time_slot);

        myViewHolder.setiRecycleritemSelectedListener(new IRecycleritemSelectedListener() {
            @Override
            public void onItemSelectedListener(View view, int pos) {
                for (CardView cardView : cardViewList)
                {
                    if (cardView.getTag() == null)
                        cardView.setCardBackgroundColor(context.getResources()
                                .getColor(android.R.color.white));
                }

                myViewHolder.cart_time_slot.setCardBackgroundColor(context.getResources()
                        .getColor(android.R.color.holo_orange_dark));

                Intent intent = new Intent(Common.KEY_ENABLE_BUTTON_NEXT);
                intent.putExtra(Common.KEY_TIME_SLOT,i);
                intent.putExtra(Common.KEY_STEP,3); //3 Steppe Git
                localBroadcastManager.sendBroadcast(intent);


            }
        });
    }

    @Override
    public int getItemCount() {
        return Common.TIME_SLOT_TOTAL;
    }

    public class MyViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener {
        TextView txt_time_slot,txt_time_slot_acıklama;
        CardView cart_time_slot;

        IRecycleritemSelectedListener iRecycleritemSelectedListener;

        public void setiRecycleritemSelectedListener(IRecycleritemSelectedListener iRecycleritemSelectedListener) {
            this.iRecycleritemSelectedListener = iRecycleritemSelectedListener;
        }

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            cart_time_slot = (CardView)itemView.findViewById(R.id.card_time_slot);
            txt_time_slot = (TextView)itemView.findViewById(R.id.txt_time_slot);
            txt_time_slot_acıklama = (TextView)itemView.findViewById(R.id.txt_time_slot_acıklama);

            itemView.setOnClickListener(this);

        }

        @Override
        public void onClick(View view) {
            iRecycleritemSelectedListener.onItemSelectedListener(view,getAdapterPosition());
        }
    }
}
