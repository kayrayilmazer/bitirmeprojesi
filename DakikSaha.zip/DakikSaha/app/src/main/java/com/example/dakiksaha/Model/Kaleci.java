package com.example.dakiksaha.Model;

import android.os.Parcel;
import android.os.Parcelable;

public class Kaleci implements Parcelable {
    private String name,username,password,kaleciID;
    private long rating;

    public Kaleci(){

    }

    protected Kaleci(Parcel in) {
        name = in.readString();
        username = in.readString();
        password = in.readString();
        kaleciID = in.readString();
        rating = in.readLong();
    }

    public static final Creator<Kaleci> CREATOR = new Creator<Kaleci>() {
        @Override
        public Kaleci createFromParcel(Parcel in) {
            return new Kaleci(in);
        }

        @Override
        public Kaleci[] newArray(int size) {
            return new Kaleci[size];
        }
    };

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public long getRating() {
        return rating;
    }

    public void setRating(long rating) {
        this.rating = rating;
    }

    public String getKaleciID() {
        return kaleciID;
    }

    public void setKaleciID(String kaleciID) {
        this.kaleciID = kaleciID;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(name);
        dest.writeString(username);
        dest.writeString(password);
        dest.writeString(kaleciID);
        dest.writeLong(rating);
    }
}
